#include <iostream>
#include <array>
using namespace std;

const int MAX_NUM = 10;

typedef array <int, MAX_NUM> Numer;

struct Lista
{
    int nelms = 0;
    Numer elm;
};

void leer (Lista& v, int& criba)
{
    cout << "Cuantos numeros desea introducir (maximo 10): ";
    cin >> v.nelms;
    while ((v.nelms < 1) || (v.nelms > 10))
    {
        cout << "Error. Cuantos numeros desea introducir (maximo 10): ";
        cin >> v.nelms;
    }
    cout << "Introduzca " << v.nelms << " numeros: ";
    for (int i = 0; i < v.nelms; i++)
    {
        cin >> v.elm[i];
    }
    cout << "Introduzca el numero de repeticiones para realizar la criba: ";
    cin >> criba;
}

void mostrar (const Lista& v2)
{
    cout << "La lista cribada es: ";
    for (int i = 0; i < v2.nelms; i++)
    {
        cout << v2.elm[i] << " ";
    }
}

int comparar (const Lista& v, int num)
{
    int cnt = v.elm[num];
    int cnt2 = 0;
    for (int i = 0; i < v.nelms; i++)
    {
        if (cnt == v.elm[i])
        {
            cnt2++;
        }
    }
    return cnt2;
}

void anyadir (Lista& v, int valor)
{
    bool repetir = true;
    for (int i = 0; i < v.nelms; i++)
    {
        if (valor == v.elm[i])
        {
            repetir = false;
        }
    }
    if (v.nelms < int(v.elm.size()) && repetir)
    {
        v.elm[v.nelms] = valor;
        ++v.nelms;
    }
}

void buscar (const Lista& v, int criba)
{
    Lista v2 = {};
    int cnt = 0;
    for (int i = 0; i < v.nelms; i++)
    {
        cnt = comparar (v, i);
        if (cnt == criba)
        {
            anyadir (v2, v.elm[i]);
        }
    }
    mostrar (v2);
}

int main ()
{
    Lista v;
    int criba;
    leer (v, criba);
    buscar (v, criba);
}
