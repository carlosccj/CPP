#include <iostream>
using namespace std;

int main ()
{
    cout << "int: " << sizeof(int) << " bytes" << endl;
    cout << "bool: " << sizeof(bool) << " bytes" << endl;
    cout << "char: " << sizeof(char) << " bytes" << endl;
    cout << "unsigned: " << sizeof(unsigned) << " bytes" << endl;
    cout << "double: " << sizeof(double) << " bytes" << endl;



}
