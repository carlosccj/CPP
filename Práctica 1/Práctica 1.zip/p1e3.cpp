#include <iostream>
using namespace std;

int main ()
{
    int num1, num2;
    cout << " Introduzca el primer numero ";
    cin >> num1;
    cout << " Introduzca el segundo numero ";
    cin >> num2;
    cout << " El valor del primer numero introducido es " << num1 << endl << " El valor del segundo numero introducido es " << num2 << endl;
}


